module.exports = {
    emojis: require("./Emojis")
}